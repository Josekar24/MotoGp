/**
 * 
 */
/**
 * 
 */
module MotoGp {
	requires java.desktop;
	requires java.sql;
}