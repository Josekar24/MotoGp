DROP DATABASE IF EXISTS MotoGp;
CREATE DATABASE IF NOT EXISTS MotoGp;
USE MotoGp;

-- Crear la tabla Equipos
CREATE TABLE IF NOT EXISTS Equipos (
    id_equipo INT PRIMARY KEY,
    nombre VARCHAR(100),
    pais VARCHAR(100)
);

-- Insertar datos en la tabla Equipos
INSERT INTO Equipos (id_equipo, nombre, pais) VALUES
(1, 'Ducati Lenovo Team', 'Italia'),
(2, 'LCR Honda', 'Francia'),
(3, 'Repsol Honda Team', 'España'),
(4, 'Aprilia Racing', 'Italia'),
(5, 'Monster Energy Yamaha MotoGP', 'Francia'),
(6, 'Pramac Racing', 'Italia'),
(7, 'Trackhouse Racing', 'España'),
(8, 'Red Bull GASGAS Tech3', 'España'),
(9, 'Red Bull KTM Factory Racing', 'Austria'),
(10, 'Gresini Racing MotoGP', 'España'),
(11, 'Pertamina Enduro VR46 Racing Team', 'Italia');

-- Crear la tabla Pilotos
CREATE TABLE IF NOT EXISTS Pilotos (
    id_piloto INT PRIMARY KEY,
    nombre VARCHAR(100),
    pais VARCHAR(100),
    edad INT,
    dorsal INT,
    id_equipo INT,
    FOREIGN KEY (id_equipo) REFERENCES Equipos(id_equipo)
);

-- Insertar datos en la tabla Pilotos
INSERT INTO Pilotos (id_piloto, nombre, pais, edad, dorsal, id_equipo) VALUES
(1, 'Pecco Bagnaia', 'Italia', 27, 1, 1),
(2, 'Johann Zarco', 'Francia', 33, 5, 2),
(3, 'Luca Marini', 'Italia', 26, 10, 3),
(4, 'Maverick Viñales', 'España', 29, 12, 4),
(5, 'Fabio Quartararo', 'Francia', 25, 20, 5),
(6, 'Franco Morbidelli', 'Italia', 29, 21, 6),
(7, 'Enea Bastianini', 'Italia', 26, 23, 1),
(8, 'Raúl Fernández', 'España', 23, 25, 7),
(9, 'Takaaki Nakagami', 'Japón', 32, 30, 2),
(10, 'Pedro Acosta', 'España', 19, 31, 8),
(11, 'Brad Binder', 'Sudáfrica', 28, 33, 9),
(12, 'Joan Mir', 'España', 26, 36, 3),
(13, 'Augusto Fernández', 'España', 26, 37, 8),
(14, 'Aleix Espargaró', 'España', 34, 41, 4),
(15, 'Alex Rins', 'España', 28, 42, 5),
(16, 'Jack Miller', 'Australia', 29, 43, 9),
(17, 'Fabio Di Giannantonio', 'Italia', 25, 49, 11),
(18, 'Marco Bezzecchi', 'Italia', 25, 72, 11),
(19, 'Alex Márquez', 'España', 26, 73, 10),
(20, 'Miguel Oliveira', 'Portugal', 29, 88, 7),
(21, 'Jorge Martín', 'España', 26, 89, 6),
(22, 'Marc Márquez', 'España', 31, 93, 10);

-- Crear la vista Pilotos_Por_Escuderia
DROP VIEW IF EXISTS Pilotos_Por_Escuderia;
CREATE VIEW Pilotos_Por_Escuderia AS 
SELECT Pilotos.nombre AS Nombre_Piloto, Equipos.nombre AS Nombre_Escuderia 
FROM Pilotos 
INNER JOIN Equipos ON Pilotos.id_equipo = Equipos.id_equipo;

-- Consulta para obtener los pilotos correspondientes a cada escudería
SELECT Nombre_Escuderia, GROUP_CONCAT(Nombre_Piloto ORDER BY Nombre_Piloto ASC) AS Pilotos
FROM Pilotos_Por_Escuderia
GROUP BY Nombre_Escuderia;

-- Crear la tabla Circuitos
CREATE TABLE IF NOT EXISTS Circuitos (
    id_circuito INT PRIMARY KEY,
    nombre VARCHAR(100),
    pais VARCHAR(100),
    longitud FLOAT
);

-- Insertar datos en la tabla Circuitos
INSERT INTO Circuitos (id_circuito, nombre, pais, longitud) VALUES
(1, 'Circuito de Jerez', 'España', 4.423),
(2, 'Circuito de Mugello', 'Italia', 5.245),
(3, 'Circuito de Le Mans', 'Francia', 4.185),
(4, 'Circuito de Catalunya', 'España', 4.627),
(5, 'Circuito de Sachsenring', 'Alemania', 3.671),
(6, 'Circuito de Assen', 'Países Bajos', 4.542),
(7, 'Circuito de Brno', 'República Checa', 5.403),
(8, 'Circuito de Red Bull Ring', 'Austria', 4.318),
(9, 'Circuito de Silverstone', 'Reino Unido', 5.901),
(10, 'Circuito de Misano', 'Italia', 4.226),
(11, 'Circuito de Aragón', 'España', 5.078),
(12, 'Circuito de Motegi', 'Japón', 4.801),
(13, 'Circuito de Buriram', 'Tailandia', 4.554),
(14, 'Circuito de Phillip Island', 'Australia', 4.445),
(15, 'Circuito de Sepang', 'Malasia', 5.543),
(16, 'Circuito de Valencia', 'España', 4.005);

-- Consulta para obtener los circuitos donde se corre
SELECT * FROM Circuitos;

CREATE TABLE Creapiloto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estatura VARCHAR(10),
    edad VARCHAR(10),
    nacionalidad VARCHAR(50),
    dorsal VARCHAR(10),
    marca_moto VARCHAR(50),
    equipo VARCHAR(50)
);

