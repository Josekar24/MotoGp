package MotoGp;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

public class MotoGp extends JFrame {
    private static final String URL = "jdbc:mysql://localhost:3306/MotoGp";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "";

    public MotoGp() {
        setTitle("Equipos de MotoGP");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 4, 8, 10));
        panel.setBackground(Color.decode("#fafcff"));

        // Agregar paneles de equipo con nombre y foto
        panel.add(createTeamPanel("Aprilia Racing", "src/Fotosgp/aprilia.png", "src/Fotosgp/aprilia2.png"));
        panel.add(createTeamPanel("Ducati Lenovo Team", "src/Fotosgp/DUCATI-LENOVO.png", "src/Fotosgp/DUCATI-LENOVO2.png"));
        panel.add(createTeamPanel("Gresini Racing MotoGP", "src/Fotosgp/gresini.png", "src/Fotosgp/gresini2.png"));
        panel.add(createTeamPanel("LCR Honda", "src/Fotosgp/logolcrhonda.png", "src/Fotosgp/logolcrhonda2.png"));
        panel.add(createTeamPanel("Monster Energy Yamaha MotoGP", "src/Fotosgp/logo-monster-energy-yamaha.png", "src/Fotosgp/logo-monster-energy-yamaha2.png"));
        panel.add(createTeamPanel("Pertamina Enduro VR46 Racing Team", "src/Fotosgp/Pertamina_Enduro_VR46_Racing_Team.png", "src/Fotosgp/Pertamina_Enduro_VR46_Racing_Team2.png"));
        panel.add(createTeamPanel("Pramac Racing", "src/Fotosgp/Logo-prima-pramac.png", "src/Fotosgp/Logo-prima-pramac2.png"));
        panel.add(createTeamPanel("Red Bull GASGAS Tech3", "src/Fotosgp/logogasgas.png", "src/Fotosgp/logogasgas2.png"));
        panel.add(createTeamPanel("Red Bull KTM Factory Racing", "src/Fotosgp/logo redbullktm.png", "src/Fotosgp/logo redbullktm2.png"));
        panel.add(createTeamPanel("Repsol Honda Team", "src/Fotosgp/logo honda.png", "src/Fotosgp/logo honda2.png"));
        panel.add(createTeamPanel("Trackhouse Racing", "src/Fotosgp/logo-trackhouse.png", "src/Fotosgp/logo-trackhouse2.png"));

        add(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JPanel createTeamPanel(String teamName, String imagePath1, String imagePath2) {
        JPanel teamPanel = new JPanel(new BorderLayout());
        teamPanel.setBackground(Color.white);
        teamPanel.setBorder(BorderFactory.createLineBorder(Color.blue, 2)); // Añadir borde azul

        JPanel imagesPanel = new JPanel(new GridLayout(1, 2)); // Panel para las imágenes
        imagesPanel.setBackground(Color.white);

        if (imagePath1 != null && imagePath2 != null) {
            ImageIcon icon1 = new ImageIcon(imagePath1);
            ImageIcon icon2 = new ImageIcon(imagePath2);
            JLabel imageLabel1 = new JLabel(new ImageIcon(icon1.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));
            JLabel imageLabel2 = new JLabel(new ImageIcon(icon2.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));
            imagesPanel.add(imageLabel1);
            imagesPanel.add(imageLabel2);
        }

        teamPanel.add(imagesPanel, BorderLayout.WEST);

        JLabel nameLabel = new JLabel(teamName);
        nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        teamPanel.add(nameLabel, BorderLayout.CENTER);

        JButton button = new JButton("Ver Detalles");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Aquí puedes abrir un nuevo JPanel con los detalles del equipo
                JFrame detailsFrame = new JFrame(teamName + " Detalles");
                JPanel detailsPanel = new JPanel(new BorderLayout());

                try {
                    Connection connection = DriverManager.getConnection(URL, USUARIO, PASSWORD);
                    String query = "SELECT * FROM Pilotos WHERE id_equipo = ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setInt(1, getTeamId(teamName));
                    ResultSet resultSet = statement.executeQuery();

                    // Panel para mostrar los detalles de los pilotos
                    JPanel pilotsPanel = new JPanel(new GridLayout(0, 1));
                    while (resultSet.next()) {
                        String nombrePiloto = resultSet.getString("nombre");
                        String pais = resultSet.getString("pais");
                        int edad = resultSet.getInt("edad");
                        JLabel label = new JLabel(nombrePiloto + " - País: " + pais + ", Edad: " + edad);
                        pilotsPanel.add(label);
                    }
                    detailsPanel.add(new JScrollPane(pilotsPanel), BorderLayout.CENTER);

                    connection.close();
                } catch (SQLException ex) {
                    System.err.println("Error al ejecutar la consulta SQL: " + ex.getMessage());
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
                }

                detailsFrame.add(detailsPanel);
                detailsFrame.pack();
                detailsFrame.setLocationRelativeTo(null);
                detailsFrame.setVisible(true);
            }
        });
        teamPanel.add(button, BorderLayout.SOUTH);

        return teamPanel;
    }

    private int getTeamId(String teamName) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        int teamId = -1;
        try {
            connection = DriverManager.getConnection(URL, USUARIO, PASSWORD);
            String query = "SELECT id_equipo FROM Equipos WHERE LOWER(nombre) = LOWER(?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, teamName);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                teamId = resultSet.getInt("id_equipo");
            } else {
                System.out.println("El equipo '" + teamName + "' no se encontró en la base de datos.");
            }
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
        return teamId;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MotoGp::new);
    }
}

