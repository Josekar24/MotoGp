package MotoGp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Circuitos extends JFrame {
    private static final String URL = "jdbc:mysql://localhost:3306/MotoGp";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "";

    public Circuitos() {
        setTitle("Circuitos de MotoGP");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 4, 8, 10));
        panel.setBackground(Color.decode("#fafcff"));

      
        try (Connection connection = DriverManager.getConnection(URL, USUARIO, PASSWORD)) {
            String query = "SELECT * FROM Circuitos";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    String nombre = resultSet.getString("nombre");
                    String pais = resultSet.getString("pais");
                    double longitud = resultSet.getDouble("longitud");
                    panel.add(createCircuitPanel(nombre, pais, longitud));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }

        add(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JPanel createCircuitPanel(String nombre, String pais, double longitud) {
        JPanel circuitPanel = new JPanel(new BorderLayout());
        circuitPanel.setBackground(Color.white);
        circuitPanel.setBorder(BorderFactory.createLineBorder(Color.red, 2)); // Añadir borde azul

        JLabel nameLabel = new JLabel(nombre);
        nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        circuitPanel.add(nameLabel, BorderLayout.NORTH);

        JTextArea detailsArea = new JTextArea();
        detailsArea.setText("País: " + pais + "\nLongitud: " + longitud + " km");
        detailsArea.setEditable(false);
        detailsArea.setOpaque(false);
        circuitPanel.add(detailsArea, BorderLayout.CENTER);

        JButton button = new JButton("Ver Detalles");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Detalles del circuito: " + nombre, "Detalles", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        circuitPanel.add(button, BorderLayout.SOUTH);

        return circuitPanel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Circuitos::new);
    }
}
